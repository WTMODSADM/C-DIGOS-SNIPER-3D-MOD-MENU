# Mod Menu with color animation
I did this for fun since a modder wanted me to make it. This will not be added to the main project, and will not be maintained. But feel free to go through the code and copy that into your project

I can't add animation for linearlayout since codes are different, I'm not good animating.

It's based on Titanic project https://github.com/romainpiel/Titanic

Have fun :))

![](https://i.imgur.com/BSGMB1L.gif)